-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2018 at 03:19 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_tbl`
--

CREATE TABLE `category_tbl` (
  `category_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catagery_discription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(2) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_tbl`
--

INSERT INTO `category_tbl` (`category_id`, `category_name`, `catagery_discription`, `status`, `created_at`, `updated_at`) VALUES
(1, 'man', 'this is man', 1, NULL, NULL),
(4, 'child', 'this is favarite color', 1, NULL, NULL),
(7, 'sports', 'its sports', 1, NULL, NULL),
(8, 'clouths', 'clouth its is', 1, NULL, NULL),
(9, 'electronic', 'all electronic here!!', 1, NULL, NULL),
(10, 'women clouth', 'this&nbsp;', 1, NULL, NULL),
(11, 'man', 'sdf', 1, NULL, NULL),
(12, 'fokinni', 'all is thay', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `manufactur`
--

CREATE TABLE `manufactur` (
  `manufactur_id` int(10) UNSIGNED NOT NULL,
  `manufactur_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufactur_discription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `manufactur`
--

INSERT INTO `manufactur` (`manufactur_id`, `manufactur_name`, `manufactur_discription`, `status`, `created_at`, `updated_at`) VALUES
(1, 'samsung', 'this onme', 1, NULL, NULL),
(2, 'nick kon', 'boot shoow', 1, NULL, NULL),
(3, 'apple pon a', 'this apple brand', 1, NULL, NULL),
(4, 'sony', 'sonis', 1, NULL, NULL),
(5, 'oppo', 'oppo', 1, NULL, NULL),
(6, 'oppo', 'oppo', 1, NULL, NULL),
(7, 'sympnony', 'symphony', 1, NULL, NULL),
(8, 'fookas', 'fookas', 0, NULL, NULL),
(9, 'kool', 'kool', 1, NULL, NULL),
(10, 'lava', 'lava', 0, NULL, NULL),
(11, 'adidas', 'shoe', 1, NULL, NULL),
(12, 'bangla clouth', 'bangla', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_07_31_150310_create_tbl_admin_table', 1),
(4, '2018_08_02_063133_create_category_tbl_table', 2),
(5, '2018_08_03_044536_create_manufactur_table', 3),
(6, '2018_08_04_060735_create_tbl_products_table', 4),
(7, '2018_08_08_180205_create_slider_tbl_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `slider_tbl`
--

CREATE TABLE `slider_tbl` (
  `slider_id` int(10) UNSIGNED NOT NULL,
  `slider_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slider_tbl`
--

INSERT INTO `slider_tbl` (`slider_id`, `slider_image`, `status`, `created_at`, `updated_at`) VALUES
(9, 'slider/dRV8Cwd1eVtlvCXbKD7R.jpg', 0, NULL, NULL),
(10, 'slider/I9fkzurO7xyDHoQuqhC1.jpg', 0, NULL, NULL),
(11, 'slider/LnNqweT2mFwEtEz3oZVP.jpg', 1, NULL, NULL),
(12, 'slider/8b8O3rGvFIm5hgKfAPta.jpg', 0, NULL, NULL),
(13, 'slider/EeE9s2haxg18ijstzkNU.jpg', 1, NULL, NULL),
(14, 'slider/Kr7pVDNMHM8wbkzoTQKf.jpg', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `admin_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_email`, `admin_password`, `admin_phone`, `admin_name`, `created_at`, `updated_at`) VALUES
(3, 'adnanjohan54@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '01937383435', 'adnan', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `manufactur_id` int(11) NOT NULL,
  `product_short_details` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_long_discription` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` double(8,2) NOT NULL,
  `product_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_size` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`product_id`, `product_name`, `category_id`, `manufactur_id`, `product_short_details`, `product_long_discription`, `product_price`, `product_image`, `product_size`, `product_color`, `status`, `created_at`, `updated_at`) VALUES
(1, 'samsung j7', 9, 1, 'this is a good&nbsp; phone for alll castomar .&nbsp; we are&nbsp; provide a goood offer for all castomar!!', '<span style=\"font-size: 13.3333px;\">this is a good&nbsp; phone for alll castomar .&nbsp; we are&nbsp; provide a goood offer for all castomar!!</span>', 23000.00, 'image/yBL0rublC3v4HRqgc4Hs.jpeg', '5.5', 'black', 1, NULL, NULL),
(4, 'shoe', 7, 11, 'this is adidas brand&nbsp;', '<span style=\"font-size: 13.3333px;\">this is adidas brand&nbsp;</span>', 5000.00, 'image/GwcEIcM1ultqCw9uS7OQ.jpg', '9', 'black', 1, NULL, NULL),
(5, 'hots clouth', 10, 12, 'new callection', '<span style=\"font-size: 13.3333px;\">new callection</span>', 500.00, 'image/fLLkmpfXdQ7BgiylvvrT.jpg', '5.5', 'red', 1, NULL, NULL),
(6, 'iphone8', 9, 3, 'dssda', 'adsafsd', 99000.00, 'image/Rm1KD5H8wtjIkfCNp6F3.png', '9', 'red', 1, NULL, NULL),
(7, 'shoe', 7, 2, 'sss', 'ss', 5000.00, 'image/h6d6EVE9E8mwuGX5PVUS.jpg', '9', 'black', 1, NULL, NULL),
(8, 'hots clouth', 10, 12, 'a', 'a', 700.00, 'image/KGe5jt08u4YIaj5GYZ8F.jpg', 'xl', 'black red', 1, NULL, NULL),
(9, 'hots clouth', 4, 12, 'ad', 'ad', 600.00, 'image/NM9VvJtrdBnP9mUgdkIJ.jpg', 'sm', 'red', 1, NULL, NULL),
(10, 'shoe', 1, 11, 'ad', 'ad', 2000.00, 'image/7rqhKWyqVFhcZlvxvcqx.jpg', '9', 'black', 1, NULL, NULL),
(11, 'tablate', 9, 1, 'ad', 'ad', 12000.00, 'image/mwH5t1xbAMIYkJmUtydi.jpg', '9', 'black', 0, NULL, NULL),
(12, 'child afron', 4, 12, 'ad', 'ca', 500.00, 'image/z1gKOAgvLTIWQX241gub.jpg', '5.5', 'red', 1, NULL, NULL),
(13, 'lahanga', 10, 12, 'llll', 'sdasa', 5000.00, 'image/LJUSWRssoXJFcmATYJ8V.jpg', 'xl', 'red', 1, NULL, NULL),
(14, 'loool', 12, 1, 'lorem 500 all is grte s sss', '<span style=\"font-size: 13.3333px;\">lorem 500 all is grte s sss</span>', 5000.00, 'image/bpbTGMBBh2URhRoX76k3.jpg', '9', 'black', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_tbl`
--
ALTER TABLE `category_tbl`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `manufactur`
--
ALTER TABLE `manufactur`
  ADD PRIMARY KEY (`manufactur_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `slider_tbl`
--
ALTER TABLE `slider_tbl`
  ADD PRIMARY KEY (`slider_id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_tbl`
--
ALTER TABLE `category_tbl`
  MODIFY `category_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `manufactur`
--
ALTER TABLE `manufactur`
  MODIFY `manufactur_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `slider_tbl`
--
ALTER TABLE `slider_tbl`
  MODIFY `slider_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
